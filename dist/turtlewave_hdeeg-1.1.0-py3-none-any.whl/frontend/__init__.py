"""
turtlewave_hdEEG - GUI for HD EEG Analysis
"""
# frontend/__init__.py
from .turtlewave_gui import main

__version__ = '1.1.0'
__all__ = ['main']

