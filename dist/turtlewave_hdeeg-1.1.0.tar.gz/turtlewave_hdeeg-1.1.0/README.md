# TurtleWave-hdEEG

High-density EEG processing for sleep research, extended from Wonambi for large datasets.

## Installation

```bash
pip install turtlewave-hdEEG